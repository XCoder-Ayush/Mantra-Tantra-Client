export const UserMantraData = [
    {
      id: 1,
     Date:1,
     mantra_chanted:20,
    },
    {
      id: 2,
      Date:2,
      mantra_chanted:30,
    },
    {
      id: 3,
      Date:3,
     mantra_chanted:10,
    },
    {
      id: 4,
      Date:4,
      mantra_chanted:40,
    },
    {
      id: 5,
      Date:5,
      mantra_chanted:50,
    },
  ];